/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package P2;

/**
 *
 * @author Aravind.Babu
 */
public class ClassTwo {
    
    //Declaring a Protected method ShowMe
    
    protected void ShowMe(){
        System.out.println("Protected Method ShowMe Accessed from package two");
    }
    //Declaring a Protected method Display
    
    protected void Display(){
        System.out.println("Protected Method Display Accessed from package two");
    }
    
}
